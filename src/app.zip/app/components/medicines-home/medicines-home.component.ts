import { HttpParams } from '@angular/common/http';
import { Component } from '@angular/core';
import { HttpService } from 'src/app/core/http/http.service';

@Component({
  selector: 'app-medicines-home',
  templateUrl: './medicines-home.component.html',
  styleUrls: ['./medicines-home.component.scss']
})
export class MedicinesHomeComponent {
  pinCode!:string;
  constructor(private http:HttpService){}
  ngOnInit(){}

  getPackageDetailsfromPinCode(){
    if(this.pinCode && this.pinCode.length ==6){
    const httpParams:HttpParams=new HttpParams()
                                .set('pinCode',this.pinCode)
   this.http.getDetailsfromServer('pincodeDetails',httpParams).subscribe((response:any)=>{

   },
   error=>{
    console.log(error);
   
    })

    }
  }
  }

